import React from 'react'
import ExpenseItem from './ExpenseItem'

function Expenses(props) {
	const arr = props.data
	return (
		<div>
			{arr.map((el) => {
				return (
					<ExpenseItem
						key={el.id}
						title={el.title}
						amount={el.amount}
						date={el.date}
					/>
				)
			})}
		</div>
	)
}

export default Expenses